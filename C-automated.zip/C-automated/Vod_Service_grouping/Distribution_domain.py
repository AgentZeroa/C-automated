# coding=utf-8
import unittest,time,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from Vod_Content_management.EpisodesList import VodSearch
from framework.Interface_test import Interface
from framework.logger import Logger

logger = Logger(logger="BrowserEngine").getlog()

#分发域绑定
class Distribution(unittest.TestCase,Interface):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_New_service(self):
        """新增业务分组"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.servicegrouping()      #点击业务分组
        homepage.collapseOnes() #点击’分发域绑定‘按钮
        Select(driver.find_element_by_id('allServiceGroup')).select_by_value('1100122106606149861830002')  #  选择业务分组  ks分发域接口测试（勿动）
        time.sleep(1)
        pipei = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text
        if pipei == '没有找到匹配的记录':
            self.New_service()
        else:
            # homepage.table_Bj()#解除绑定
            homepage.bo_right()#所有复选
            homepage.customtoolbar()#解除绑定
            driver.switch_to_alert().accept()
            homepage.ffy_sx_queding()#确认
            self.New_service()

    def New_service(self):
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.custom_toolbar()  # 点击新增
        value = driver.find_element_by_xpath('//*[@id="domaincode"]/option[17]').text
        Select(driver.find_element_by_id('domaincode')).select_by_value('2100090106975227179280047')  # 分发域测试（测试勿动）
        homepage.domain_form()  # 点击绑定
        try:
            assert VodSearch.get_ass_text(self) == '绑定成功！'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()  # 确认
        text_center = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        try:
            assert text_center == value
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.custom_toolbar()  # 点击新增
        value1 = driver.find_element_by_xpath('//*[@id="domaincode"]/option[16]').text
        logger.info('value1 is:%s'%value)
        Select(driver.find_element_by_id('domaincode')).select_by_value('2100090070261383040150005')  # 上海视频基地CDN分发域
        homepage.domain_form()  # 点击绑定
        try:
            assert VodSearch.get_ass_text(self) == '绑定成功！'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()  # 确认
        text_center1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[2]/td[3]').text
        logger.info('text_center1 is:%s' % text_center1)
        try:
            assert text_center1 == value1
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_Priority_up(self):
        """优先级上移"""
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.servicegrouping()  # 点击业务分组
        # homepage.collapseOnes()  # 点击’分发域绑定‘按钮
        # Select(driver.find_element_by_id('allServiceGroup')).select_by_value('1100122106019578867330134')
        # time.sleep(1)
        domain = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text#上海
        domain1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[2]/td[3]').text#测试
        encoding = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[2]/td[5]').text
        homepage.tab_Deta()#点击上移按钮
        try:
            assert VodSearch.get_ass_text(self) == '分发域：' + encoding + ',优先级已经上移完毕。'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()   #确认
        text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text#测试
        text1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[2]/td[3]').text
        try:
            assert text == domain1 and text1 == domain
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        time.sleep(1)
        # Interface.FJLT_domainCode(self)     #分发域调序接口

    def test_Unbound(self):
        """解除绑定"""
        homepage = HomePage(self.driver)
        driver = self.driver
        try:
            checkboxes = driver.find_elements_by_css_selector('input[type=checkbox]')
            for checkbox in checkboxes:
                checkbox.click()
        except Exception as e:
            logger.info(e)
        time.sleep(2)
        homepage.customtoolbar()#点击解除绑定
        alert = driver.switch_to_alert()  # 定位弹出对话框
        alert.accept()  # 点击对话框“确定”
        time.sleep(3)
        try:
            assert VodSearch.get_ass_text(self) == '解除绑定成功！'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()#确认
        matching = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text
        try:
            assert matching == '没有找到匹配的记录'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()
