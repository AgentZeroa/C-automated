# coding=utf-8
import unittest,time,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from Oms_Navigation_management.Global_navigation import Global
from framework.logger import Logger
logger = Logger(logger="BrowserEngine").getlog()

#终端列表
class List_terminal(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_search(self):
        """搜索"""
        Global.Oms_sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 点击终端管理
        Select(driver.find_element_by_id('allServiceCombo')).select_by_value(
            '1100121023874101446610014')  # --选择业务组合--   福建联通
        time.sleep(2)
        mac_addres = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[1]').text  #  获取MAC地址
        Terminal_rule = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text  #  获取终端规则
        homepage.searchBtn()  #  点击搜索
        homepage.intomac(mac_addres)  #  输入MAC
        homepage.searchDiv_lable()  #  点击终端规则
        homepage.searchDiv_lable_input(Terminal_rule)  #  输入终端规则
        homepage.searchDiv_lable_input(Keys.ENTER)  #
        homepage.searchByName()  #  点击搜索
        after_mac = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[1]').text  #  获取搜索后的MAC地址
        after_Terminal = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[4]').text  #  获取搜索后的apk版本
        try:
            assert after_mac == mac_addres and after_Terminal == Terminal_rule
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

        """详细测试：状态 类型"""
        homepage.searchReset()  # 点击重置
        Select(driver.find_element_by_id('status')).select_by_value('2')  #  选择状态：停用
        time.sleep(5)
        asname01 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text  # 获取得到的结果
        try:
            assert asname01 == "没有找到匹配的记录"
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()


    def test_Reset(self):
        """重置"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.searchReset()  #  点击重置
        mac = driver.find_element_by_xpath('//*[@id="mac"]').text
        # apk = driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[3]/div/button/span[1]').text
        try:
            assert mac == ''
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_Advanced_search(self):
        """高级搜索"""
        homepage = HomePage(self.driver)
        driver = self.driver
        mac_addres = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[1]').text  # 获取MAC地址
        terminal_addres = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text  # 获取终端规则
        vendorCode = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[6]').text  #  终端厂商
        typeCode = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[7]').text  #  终端类型
        chipVendorCode = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text  #  芯片厂商
        status = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[10]').text  #  激活状态
        homepage.searchMore()  #  点击高级搜索
        homepage.search_mac(mac_addres)  #  输入MAC
        Select(driver.find_element_by_id('search_vendorCode')).select_by_visible_text(vendorCode)  # --选择终端厂商
        time.sleep(1)
        Select(driver.find_element_by_id('search_typeCode')).select_by_visible_text(
            typeCode)  # --选择终端型号
        time.sleep(1)
        Select(driver.find_element_by_id('search_chipVendorCode')).select_by_visible_text(
            chipVendorCode)  # --选择芯片厂商
        time.sleep(1)
        homepage.Click_ternial()  # 点击终端规则
        homepage.Type_ternial(terminal_addres)  # 输入终端规则
        homepage.Type_ternial(Keys.ENTER)  #
        time.sleep(1)
        Select(driver.find_element_by_id('search_status')).select_by_visible_text(
            status)  # --选择状态
        time.sleep(1)
        homepage.dj_sous()  #  点击搜索
        after_mac = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[1]').text  # 获取搜索后的MAC地址
        try:
            assert after_mac == mac_addres
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()


    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()