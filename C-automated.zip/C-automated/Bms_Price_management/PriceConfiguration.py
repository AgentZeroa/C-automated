# coding=utf-8
import unittest,time
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from Vod_Content_management.EpisodesList import VodSearch
from framework.logger import Logger
logger = Logger(logger="BrowserEngine").getlog()


# 价签管理 价签配置
class Priceconfiguration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def Bms_sign_in(self):
        """Bms登录"""
        VodSearch.test_Sign_in(self)
        driver = self.driver
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/a/span').click()  # 点击下拉
        time.sleep(2)
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/ul/li[2]/a').click()  # 选择bms
        time.sleep(2)


    def test_Newly_added(self):
        """新增"""
        self.Bms_sign_in()
        homepage = HomePage(self.driver)
        homepage.Click_price()        # 点击价签管理
        homepage.Click_increase()        # 点击新增
        homepage.Type_month('1')   # 输入有效时长
        homepage.Type_price('666')   # 输入价格
        homepage.Click_save()      # 点击保存
        homepage.ffy_sx_queding()      # 点击弹出框确认

    def gettext(self):
        driver = self.driver
        self.name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text
        self.paytype = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[6]').text  # 付费类型
        self.timelength = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[7]').text  # 有效时长
        self.price = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text  # 价格
        self.state = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[9]').text  # 状态
        return self.name, self.paytype, self.timelength, self.price, self.state

    def test_search(self):
        """搜索"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.add_names('包时段-1月-6.66元')  # 输入搜索内容
        homepage.search_name1()  # 点击搜索
        self.gettext()
        try:
            assert self.name == '包时段-1月-6.66元' and self.paytype == '包时段' and self.timelength == '1个月' and self.price == '6.66元' and self.state == '生效'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    def test_edit(self):
        """编辑"""
        # VodSearch.test_Sign_in(self)
        driver = self.driver
        # driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/a/span').click()  # 点击下拉
        # time.sleep(2)
        # driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/ul/li[2]/a').click()  # 选择bms
        # time.sleep(2)
        homepage = HomePage(self.driver)
        # homepage.Click_price()  # 点击价签管理
        homepage.Click_edit1()  # 点击编辑
        driver.find_element_by_css_selector('html body.modal-open div#main.container-fluid div.row div.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main div#edit_price_dialog.modal.fade.in div.modal-dialog.'
                                     'modal-lg div.modal-content div.modal-body form#edit_price_form.form-horizontal div.form-group div.col-sm-7 label.radio-inline input#dianbo').click()
        time.sleep(1)  # 点击点播
        driver.find_element_by_css_selector('html body.modal-open div#main.container-fluid div.row div.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main div#edit_price_dialog.modal.fade.in'
                                            ' div.modal-dialog.modal-lg div.modal-content div.modal-body form#edit_price_form.form-horizontal div.form-group div.col-sm-7 input#price.form-control').clear() #  清空

        # homepage.clear_edit2()  #  清空
        driver.find_element_by_css_selector(
            'html body.modal-open div#main.container-fluid div.row div.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main div#edit_price_dialog.modal.fade.in'
            ' div.modal-dialog.modal-lg div.modal-content div.modal-body form#edit_price_form.form-horizontal div.form-group div.col-sm-7 input#price.form-control').send_keys('888')
        time.sleep(1)
        driver.find_element_by_xpath('/html/body/div[3]/div/div[2]/div[7]/div/div/div[2]/form/div[6]/div/select/option[2]').click() #选择效果状态
        time.sleep(2)
        homepage.Click_save2()  # 点击保存
        homepage.ffy_sx_queding()  # 点击确认
        self.gettext()
        try:
            assert self.name == '点播-1小时-8.88元' and self.paytype == '点播' and self.timelength == '1小时' and self.price == '8.88元' and self.state == '失效'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_delete(self):
        """删除"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.table_Input()  # 点击对勾
        homepage.Click_delete()  # 点击删除
        alert = driver.switch_to_alert()  # 定位弹出对话框
        alert.accept()  # 点击对话框“确定”
        homepage.clear_names()  # 清空
        homepage.add_names('点播-1小时-8.88元')  # 输入搜索内容
        homepage.search_name1()  # 点击搜索
        text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text    # 没有找到匹配的记录
        try:
            assert text == '没有找到匹配的记录'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()





