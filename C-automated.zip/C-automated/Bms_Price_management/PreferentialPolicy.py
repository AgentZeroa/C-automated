# coding=utf-8
import unittest,time,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from Bms_Price_management.PriceConfiguration import Priceconfiguration
from framework.logger import Logger
logger = Logger(logger="BrowserEngine").getlog()

test_name = 'AgentZero优惠'
# 价签管理 优惠策略
class Preferentialpolicy(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_Newly_added(self):
        """新增"""
        Priceconfiguration.Bms_sign_in(self)  #  BMS登录
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.Click_price()        # 点击价签管理
        homepage.collapseOnes()  # 点击优惠策略
        homepage.Click_add()        # 点击新增
        driver.find_element_by_css_selector('html body.modal-open div#main.container-fluid div.row div.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main div#create_discount_dialog.modal.fade.in div.'
                                            'modal-dialog.modal-lg div.modal-content div.modal-body form#create_discount_form.form-horizontal div.form-group div.col-sm-7 input#name.form-control').send_keys(test_name)  # 输入名称
        homepage.attribute_value('2')   # 输入折扣值
        homepage.Click_time1()   # 点击生效时间
        driver.find_element_by_xpath('/html/body/div[5]/div[3]/table/tbody/tr[4]/td[6]').click()
        homepage.Click_time2()  # 点击失效时间
        driver.find_element_by_xpath('/html/body/div[6]/div[3]/table/tbody/tr[4]/td[7]').click()
        homepage.Click_save3()      # 点击保存
        homepage.button_2()      # 点击弹出框确认


    def test_search(self):
        """搜索"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.add_names(test_name)  # 输入搜索内容
        homepage.search_name1()  # 点击搜索
        name1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[4]').text
        try:
            assert name1 == test_name
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    def test_edit(self):
        """编辑"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.Click_Determine3()  # 点击编辑
        driver.find_element_by_css_selector('html body.modal-open div#main.container-fluid div.row div.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main '
                                            'div#edit_discount_dialog.modal.fade.in div.modal-dialog.modal-lg div.modal-content div.modal-body form#edit_discount_form.form-horizontal div.form-group div.col-sm-7 input#name.form-control').send_keys('编辑测试')  # 输入名称
        homepage.Click_save4()  # 点击保存
        time.sleep(2)
        homepage.button_2()  # 点击确认
        homepage.add_names('编辑测试')  # 输入搜索内容
        homepage.search_name1()  # 点击搜索
        name2 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[4]').text
        try:
            assert name2 == test_name+'编辑测试'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_delete(self):
        """删除"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.table_Input()  # 点击对勾
        homepage.Click_delete2()  # 点击删除
        alert = driver.switch_to_alert()  # 定位弹出对话框
        alert.accept()  # 点击对话框“确定”
        time.sleep(2)
        homepage.clear_names()
        homepage.add_names(test_name+'编辑测试')  # 输入搜索内容
        homepage.search_name1()  # 点击搜索
        text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text    # 没有找到匹配的记录
        try:
            assert text == '没有找到匹配的记录'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()





