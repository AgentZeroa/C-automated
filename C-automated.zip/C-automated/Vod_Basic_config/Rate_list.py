# -*- coding:utf-8 -*-
import unittest,time,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from Vod_Content_management.EpisodesList import VodSearch

ratename = '1AHQHY-4M'
#码率列表
class Rate(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_Newly_added(self):
        """新增"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.jc_peizhi()   #点击基础配置
        homepage.ratecollapseThree()#点击码率列表
        homepage.rateaddBtn()#点击新增
        homepage.add_names(ratename)
        homepage.alias('HQHY')
        rand = random.randint(10000000,20000000)
        rand1 = random.randint(20000000,30000000)
        driver.find_element_by_xpath('//*[@id="min"]').send_keys(rand)
        driver.find_element_by_xpath('//*[@id="max"]').send_keys(rand1)
        time.sleep(1)
        homepage.bitRateSubmit()  # 点击保存
        try:
            assert VodSearch.get_ass_text(self) == '新增码率成功'
            print('Test pass.')
        except Exception as e:
            print("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()#确认
        text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        try:
            assert text == ratename
            print('Test pass.')
        except Exception as e:
            print("Test fail.", format(e))
            homepage.get_windows_img()

    def test_edit(self):
        """编辑"""
        homepage = HomePage(self.driver)
        driver = self.driver
        # test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        homepage.edit_table()#点击编辑
        homepage.add_names('（edit）')#输入名称
        # Select(driver.find_element_by_id('isUse')).select_by_value('1')
        homepage.bitRateSubmit()#点击保存
        try:
            assert VodSearch.get_ass_text(self) == '更新码率成功'
            print('Test pass.')
        except Exception as e:
            print("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()#确认
        name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        # state = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[5]').text
        try:
            assert name == ratename + '（edit）'
            print('Test pass.')
        except Exception as e:
            print("Test fail.", format(e))
            homepage.get_windows_img()

    def test_delete(self):
        """删除"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.table_input()#点击复选
        homepage.ratedeleteBtn()#点击删除
        driver.switch_to_alert().accept()  # 定位弹出对话框
        try:
            assert VodSearch.get_ass_text(self) == '已删除[1]条,删除失败[0]条'
            print('Test pass.')
        except Exception as e:
            print("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.ffy_sx_queding()#确认

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()