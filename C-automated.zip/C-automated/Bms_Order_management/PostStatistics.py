# -*- coding:utf-8 -*-
import unittest,time,requests
import urllib.request,json,hashlib,base64,hmac
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from Vod_Content_management.EpisodesList import VodSearch
from framework.logger import Logger
from framework.Interface_test import Interface

userid = '13167568664'
logger = Logger(logger="BrowserEngine").getlog()
#
class Poststa(unittest.TestCase,Interface):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def Order(self):
        """订购"""
        xml_request = '<?xml version="1.0" encoding="utf-8" standalone="yes"?><orderRelationSyncRequest><phoneNumber>13167568664</phoneNumber>' \
                      '<userCity>14</userCity><apppId>KS-JSYD-BY</apppId><opType>0</opType></orderRelationSyncRequest>'
        url = 'http://10.3.1.106:8887/bms_interface/1.0/orderInfo/orderPaySyncByAdditional'
        headers = {
            'Authorization': 'HDCAUTH appid="108000000000000080",token="35zdE/idL6Zp8t/SzDwx7ZFLhPU7wlbCGDhlRNpc578="'}  # 订购
        request = requests.post(url=url, headers=headers, data=xml_request)
        logger.info(request.text)

    def Unsubscribe(self):
        """退订"""
        xml_request = '<?xml version="1.0" encoding="utf-8" standalone="yes"?><orderRelationSyncRequest><phoneNumber>13167568664</phoneNumber>' \
                      '<userCity>14</userCity><apppId>KS-JSYD-BY</apppId><opType>1</opType></orderRelationSyncRequest>'
        url = 'http://10.3.1.106:8887/bms_interface/1.0/orderInfo/orderPaySyncByAdditional'
        headers = {
            'Authorization': 'HDCAUTH appid="108000000000000080",token="40DTNG6lg1dn1LRqzYSwJc9VxJOfGwYFwviWTg2AeuY="'}  # 退订
        request = requests.post(url=url, headers=headers, data=xml_request)
        logger.info(request.text)

    def Calllogic(self):
        """调用逻辑"""
        homepage = HomePage(self.driver)
        driver = self.driver
        self.Order()
        time.sleep(2)
        homepage.searchByName()  # 搜索
        externalUserId = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[8]').text
        status = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[10]').text
        try:
            assert externalUserId == userid and status == '生效'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        Interface.Get_package_tag(self)
        time.sleep(3)
        self.Unsubscribe()
        homepage.searchByName()  # 搜索
        invalid = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[10]').text
        try:
            assert invalid == '失效'
            logger.inf('Test pass')
        except Exception as e:
            logger.inf('Test fail.', format(e))
            homepage.get_windows_img()
        time.sleep(3)
        Interface.Unsubscribe(self)

    def test_business_order(self):
        """营业厅订购"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/a/span').click()  # 点击下拉
        time.sleep(2)
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/ul/li[2]/a').click()  # 选择bms
        time.sleep(2)
        homepage.busines_com()  # 点击订单管理
        homepage.collapseOnes()  # 点击订单列表
        homepage.searchBtn()  # 点击搜索
        homepage.Type_tripartite(userid)  # 输入三方用户
        homepage.searchByName()  # 搜索
        try:
            threeid = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text  # 获取三方用户标识
            if threeid == userid:
                homepage.table_input0()  # 点击 复选
                homepage.deleteOrder_btn()  # 点击删除
                driver.switch_to_alert().accept()
                time.sleep(3)
                self.Calllogic()
            else:
                self.Calllogic()
        except Exception as e:
            logger.info(e)

    def test_H5_page(self):
        """H5页面订购"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/a/span').click()  # 点击下拉
        time.sleep(2)
        driver.find_element_by_xpath('/html/body/div[1]/div/div[1]/ul/li/ul/li[2]/a').click()  # 选择bms
        time.sleep(2)
        homepage.busines_com()  # 点击订单管理
        homepage.collapseOnes()  # 点击订单列表
        homepage.searchBtn()  # 点击搜索
        homepage.Type_tripartite(userid)  # 输入三方用户
        homepage.searchByName()  # 搜索
        threeid = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text  # 获取三方用户标识
        if threeid == userid:
            homepage.table_input0()  # 点击 复选
            homepage.deleteOrder_btn()  # 点击删除
            driver.switch_to_alert().accept()
            time.sleep(3)
            self.Create_an_order()
            homepage.searchByName()  # 搜索
            externalUserId = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[8]').text
            status = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[10]').text
            try:
                assert externalUserId == userid and status == '生效'
                logger.info('Test pass')
            except Exception as e:
                logger.info('Test fail.', format(e))
                homepage.get_windows_img()
        else:
            self.Create_an_order()

    def Create_an_order(self):
        """H5创建订单"""
        url = 'http://113.208.112.150:8801/bms_api/order!createOrder?userCode=1300110023465848762820066&serviceComboCode=1100121022149038548320021&assetCode=2100130022392381135061416&priceCode=1200150023232090714630166&payType=0&externalUserId=13167568664'
        urlh5 = '/1.0/orderInfo/orderPaySyncByH5'
        urls = 'http://10.3.1.106:8887/bms_interface'+ urlh5 + ''
        app_key = 'rr5a58e3829i50e39pis169a1sp3arr4'
        get_url = urllib.request.urlopen(url).read()
        get = get_url.decode('utf-8')
        ret = json.loads(get)
        program = ret["retInfo"]['orderCode']
        #  token加密
        body = '{"transid":"2017101211581414985351101","orderid":"' + program + '","paytime":"20171012122814","orderstate":"0","reserved":"4"}'
        md5_encryp = hashlib.md5()
        md5_encryp.update(body.encode('utf-8'))
        encryption = md5_encryp.hexdigest()  # request body 进行md5加密
        code = base64.b16encode(encryption.encode('utf-8'))   #  将通过md5加密后的request body 通过base16加密
        code_str = str(code.upper(), 'utf-8')  # 小写字母转成大写字母
        De_code = base64.b64decode(app_key)  # 将APP_KEY进行Base64解码
        Secret = urlh5 + code_str
        signature = hmac.new(De_code, Secret.encode('utf-8'), digestmod=hashlib.sha256).hexdigest()  # 进行encodeHmacSHA256
        # H5页面订购
        headers = {'Authorization': 'HDCAUTH appid="001110000",token="' + signature + '"'}
        request = requests.post(url=urls, headers=headers, data=body)
        logger.info(request.text)

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()