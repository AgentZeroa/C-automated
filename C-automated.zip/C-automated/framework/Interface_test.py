# -*- coding:utf-8 -*-
import configparser     #处理ini文件
import os.path
import urllib.request,re,json
from framework.logger import Logger
from pageobjects.cibn_homepage import HomePage
import random

logger = Logger(logger="BrowserEngine").getlog()
test_name = '择天记 高清'
details_test = '详情测试'
# img_url = 'featurepic=http://images.aliyun.ott.guttv.cibntv.net/560418dc2cf003516b4358d33116da18'
img_url = 'featurepic=http://113.208.112.134:4869/560418dc2cf003516b4358d33116da18'


class Interface(object):
    dir = os.path.dirname(os.path.abspath('.'))  # 相对路径获取方法
    chrome_driver_path = dir + '/tools/chromedriver.exe'
    ie_driver_path = dir + '/tools/IEDriverServer.exe'

    def __init__(self, driver):
        self.driver = driver

    def Browser(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        vod_api_url = config.get("testServer", "vod_api_URL")
        logger.info("The test server url is: %s" % vod_api_url)
        get_url = urllib.request.urlopen(vod_api_url).read()
        self.Code = get_url.decode('utf-8')
        self.ret_data = json.loads(self.Code)
        return self.ret_data

    def vod_api_browser(self):
        '''上线接口测试'''
        homepage = HomePage(self.driver)
        self.Browser()
        device_id = self.ret_data["retCode"]
        if device_id == '00000000':
            prod = re.findall('.*?"productName":"(.*?)"', self.Code)
            join = ''.join(prod)
            try:
                assert join == '大面曹天'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def vod_api_downline(self):
        '''下线接口测试'''
        homepage = HomePage(self.driver)
        self.Browser()
        device_id = self.ret_data["retCode"]
        if device_id == 'A0000000':
            retmsg = self.ret_data["retMsg"]
            try:
                assert retmsg == '无对应数据'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Cp_edit(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Cp_edit_URL = config.get("testServer", "Cp_edit_URL")
        logger.info("The test server url is: %s" % Cp_edit_URL)
        get_url = urllib.request.urlopen(Cp_edit_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_pr = json.loads(Code)
        return self.ret_pr

    def Cp_edits(self):
        '''修改节目集名称'''
        homepage = HomePage(self.driver)
        self.Cp_edit()
        device_id = self.ret_pr["retCode"]
        if device_id == 'E0000009':
            cp = self.ret_pr["retMsg"]
            cpName = re.findall(".*?'seriesName': '(.*?)'", str(cp))[0]
            try:
                assert cpName == '梦想世界（测试）'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Program(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Program_URL = config.get("testServer", "Program_URL")
        logger.info("The test server url is: %s" % Program_URL)
        get_url = urllib.request.urlopen(Program_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_pro = json.loads(Code)
        return self.ret_pro

    def ProgramName(self):
        program = self.ret_pro["retMsg"]["programList"]
        self.programName = re.findall(".*?'programName': '(.*?)'", str(program))[0]
        self.seriesInfo = re.findall(".*?'programName': '(.*?)'", str(program))[1]
        self.InfoByCode = re.findall(".*?'programSequence': '(.*?)'", str(program))[1]
        return self.programName

    def getSeriesInfo(self):
        '''修改集数/期数'''
        homepage = HomePage(self.driver)
        self.Program()
        device_id = self.ret_pro["retCode"]
        if device_id == '00000000':
            self.ProgramName()
            try:
                assert self.seriesInfo == '大面曹天 01' and self.InfoByCode == '2'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Program_online(self):
        homepage = HomePage(self.driver)
        self.Program()
        device_id = self.ret_pro["retCode"]
        if device_id == '00000000':
            self.ProgramName()
            try:

                assert self.programName == '大面曹天 01'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Program_downline(self):
        homepage = HomePage(self.driver)
        self.Program()
        device_id = self.ret_pro["retCode"]
        if device_id == '00000000':
            self.ProgramName()
            try:
                assert self.programName != '大面曹天 01'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Product(self):
        code_name = open('D:\\code.txt').read()
        Product_URL = 'http://10.3.1.107:8804/vod_api/assetList!getProductList?serviceGroupCode=1100122022055962258270018&packageCodes='
        add = '&pageLimit=200&pageNum=0&isAll=1'
        logger.info("The test server url is: %s" % Product_URL + code_name + add)
        get_url = urllib.request.urlopen(Product_URL + code_name +add).read()
        Code = get_url.decode('utf-8')
        self.ret_Product = json.loads(Code)
        return self.ret_Product

    def Product_downline(self):
        '''新增产品包'''
        homepage = HomePage(self.driver)
        self.Product()
        device_id = self.ret_Product["retCode"]
        if device_id == '00000000':
            program = self.ret_Product["retMsg"]["listInfo"]
            programName = re.findall(".*?'productName': '(.*?)'", str(program))[0]
            try:
                assert programName == '厉害了我的歌 高清'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Binding_package(self):
        """产品加入产品包中"""
        homepage = HomePage(self.driver)
        self.Product()
        device_id = self.ret_Product["retCode"]
        if device_id == '00000000':
            program = self.ret_Product["retMsg"]["listInfo"]
            programName = re.findall(".*?'productName': '(.*?)'", str(program))[1]
            try:
                assert programName == '大话天仙'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Product_No_downline(self):
        """产品从产品包去除"""
        homepage = HomePage(self.driver)
        self.Product()
        device_id = self.ret_Product["retCode"]
        if device_id == '00000000':
            program = self.ret_Product["retMsg"]["listInfo"]
            programName = re.findall(".*?'productName': '(.*?)'", str(program))[0]
            try:
                assert programName != '厉害了我的歌 高清'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Product_No_Column_tree(self):
        """产品包从栏目树去除"""
        homepage = HomePage(self.driver)
        self.Product()
        device_id = self.ret_Product["retCode"]
        try:
            assert device_id == 'ES000002'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def Tree_state(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Tree_state_URL = config.get("testServer", "Tree_state_URL")
        logger.info("The test server url is: %s" % Tree_state_URL)
        get_url = urllib.request.urlopen(Tree_state_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_tree = json.loads(Code)
        return self.ret_tree


    def Tree_enable(self):
        homepage = HomePage(self.driver)
        self.Tree_state()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][1]
            name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            sub = self.ret_tree["retMsg"][2]
            subsection = re.findall(".*?'name': '(.*?)'", str(sub))[0]
            try:
                assert name == '电影' and subsection == '国产大片'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Binding_tree(self):
        #业务分组产品包解绑栏目树测试
        homepage = HomePage(self.driver)
        self.Tree_state()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][3]
            name = re.findall(".*?'packageCodes': '(.*?)'", str(program))[0]
            try:
                assert name == '2100130022963222138720075'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Unbundling_tree(self):
        #业务分组产品包绑定栏目树测试
        homepage = HomePage(self.driver)
        self.Tree_state()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][3]
            name = re.findall(".*?'packageCodes': '(.*?)'", str(program))[0]
            try:
                assert name == ''
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Add_column_interface(self):
        """添加栏目接口测试"""
        homepage = HomePage(self.driver)
        self.Tree_state()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][4]
            add_name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_name == '子栏目'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Globa_navigation(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Globa_navigation_URL = config.get("testServer", "Globa_navigation_URL")
        logger.info("The test server url is: %s" % Globa_navigation_URL)
        get_url = urllib.request.urlopen(Globa_navigation_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_m = json.loads(Code)
        return self.ret_m

    def Globa_navigation02(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Globa_navigation_agentzero = config.get("testServer", "Globa_navigation_agentzero")
        logger.info("The test server url is: %s" % Globa_navigation_agentzero)
        get_url = urllib.request.urlopen(Globa_navigation_agentzero).read()
        Code = get_url.decode('utf-8')
        self.ret_m = json.loads(Code)
        return self.ret_m

    def Bound_before_Interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation02()
        device_id = self.ret_m["retCode"]
        retmsg = self.ret_m["retMsg"]
        try:

            assert retmsg == "无对应数据" and device_id == 'A0000000'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def Bound_After_Interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation02()
        device_id = self.ret_m["retCode"]
        combo_id = self.ret_m["retMsg"]
        add_name = re.findall(".*?'id': '(.*?)'", str(combo_id))[0]
        try:
            assert add_name == "1100121106682455570680027" and device_id == '00000000'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def name_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            program = self.ret_m["retMsg"]
            add_name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_name == details_test
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Re_get(self):
        program = self.ret_m["retMsg"]
        self.add_name = re.findall(".*?'name': '(.*?)'", str(program))[0]
        self.action = re.findall(".*?'action': '(.*?)'", str(program))[0]
        self.serviceType = re.findall(".*?'serviceType': '(.*?)'", str(program))[0]
        return self.add_name,self.action,self.serviceType

    def Vod_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_PROGRAM_LIST' and self.serviceType == 'VOD'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Live_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_LIVEPLAYER' and self.serviceType == 'LIVE'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def App_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_APP' and self.serviceType == 'APP'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Setting_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_SETTINGS' and self.serviceType == 'SETTING'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Favoerite_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_FAVOR' and self.serviceType == 'FAVOERITE'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def History_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_HISTORY' and self.serviceType == 'HISTORY'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def About_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_ABOUT_US' and self.serviceType == 'ABOUT'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Special_index_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.Re_get()
            try:
                assert self.add_name == details_test and self.action == 'OPEN_SPECIAL_INDEX' and self.serviceType == 'SPECIAL_INDEX'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def CategoryCode_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            program = self.ret_m["retMsg"]
            category = re.findall(".*?'categoryCode': '(.*?)'", str(program))[0]
            categoryTree = re.findall(".*?'categoryTreeCode': '(.*?)'", str(program))[0]
            try:
                assert category == '2100050106975149392980003' and categoryTree == '2100050106975149392980003'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Recommend_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            program = self.ret_m["retMsg"]
            recommend = re.findall(".*?'recommendCode': '(.*?)'", str(program))[0]
            try:
                assert recommend == '1100070106059525140550004'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Del_name_interface(self):
        homepage = HomePage(self.driver)
        self.Globa_navigation()
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            program = self.ret_m["retMsg"]
            add_name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_name != details_test
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Recommended_bit_public(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Recommended_bit_URL = config.get("testServer", "Recommended_bit_URL")
        logger.info("The test server url is: %s" % Recommended_bit_URL)
        get_url = urllib.request.urlopen(Recommended_bit_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_m = json.loads(Code)
        return self.ret_m

    def upMovebtn_interface(self):
        self.Recommended_bit_public()
        program = self.ret_m["retMsg"]['recommendContent']
        self.add_name = re.findall(".*?'name': '(.*?)'", str(program))[3]
        self.idx_num = re.findall(".*?'idx': (.*?),", str(program))[3]
        # return self.add_name,self.idx_num

    def Newly_added_interface(self):
        self.Recommended_bit_public()
        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            program = self.ret_m["retMsg"]['recommendContent']
            self.add_name = re.findall(".*?'name': '(.*?)'", str(program))[3]
            self.idx_num = re.findall(".*?'idx': (.*?),", str(program))[3]
            # self.upMovebtn_interface()
            try:
                assert self.add_name == test_name and self.idx_num == '4'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def delete_inter(self):
        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.upMovebtn_interface()
            try:
                assert self.add_name == '神探夏洛克' and self.idx_num == '4'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def No_nine(self):
        self.Recommended_bit_public()
        program = self.ret_m["retMsg"]['recommendContent']
        self.nine_name = re.findall(".*?'name': '(.*?)'", str(program))[8]
        self.idx_nine = re.findall(".*?'idx': (.*?),", str(program))[8]
        return self.nine_name,self.idx_nine

    def btnMoveTo_interface(self):

        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.No_nine()
            try:
                assert self.nine_name == '神探夏洛克' and self.idx_nine == '9'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Top_interface(self):
        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.No_nine()
            try:
                assert self.nine_name == '微微一笑很倾城 高清' and self.idx_nine == '9'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Shutdown_interface(self):
        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.No_nine()
            try:
                assert self.nine_name == '郑成功' and self.idx_nine == '9'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Edit_inter(self):
        homepage = HomePage(self.driver)
        device_id = self.ret_m["retCode"]
        if device_id == '00000000':
            self.upMovebtn_interface()
            try:
                assert self.add_name == test_name + '（编辑）' and self.idx_num == '4'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        JsEpg5_URL = config.get("testServer", "JSEPG5_URL")
        logger.info("The test server url is: %s" % JsEpg5_URL)
        get_url = urllib.request.urlopen(JsEpg5_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_js = json.loads(Code)
        return self.ret_js

    def Change_name(self):
        program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
        self.move_name = re.findall(".*?'showName': '(.*?)'", str(program))[0]
        self.move_idx = re.findall(".*?'action': (.*?),", str(program))[0]

    def JsEpg5_add(self):
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            self.Change_name()
            try:
                assert self.move_name == test_name and self.move_idx == "'OPEN_DETAIL'"
                logger.info('Test pass.action:%s'%self.move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def customization(self):
        #业务组合--推荐位定制
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_type = re.findall(".*?'serviceType': '(.*?)'", str(program))[0]
            move_name = re.findall(".*?'name': (.*?),", str(program))[0]
            replace = re.findall(".*?'replaceDesc': (.*?),", str(program))[0]
            try:
                assert move_type == 'GAME' and move_name == "'游戏'" and replace == "'类型:个性化'"
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_add_package(self):
        #详情新增产品包
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_name = re.findall(".*?'showName': '(.*?)'", str(program))[1]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[1]
            try:
                assert move_name == '爆款网综专题（江苏移动）' and move_idx == "'OPEN_SPECIAL_TEMPLATE_1'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_add_column(self):
        #详情新增栏目
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_name = re.findall(".*?'showName': '(.*?)'", str(program))[2]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[2]
            try:
                assert move_name == '' and move_idx == "'OPEN_PROGRAM_LIST'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_add_special(self):
        #详情新增专题
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_name = re.findall(".*?'showName': '(.*?)'", str(program))[3]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[3]
            try:
                assert move_name == '德云社' and move_idx == "'OPEN_SPECIAL_INDEX'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_add_program(self):
        #详情新增节目
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_name = re.findall(".*?'showName': '(.*?)'", str(program))[4]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[4]
            try:
                assert move_name == '极限挑战 第二季 高清' and move_idx == "'OPEN_PROGRAM'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_add_H5(self):
        #H5页面
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[5]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[5]
            try:
                assert move_name == 'H5' and move_idx == "'OPEN_H5'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_settingpage(self):
        #业务类型--设置页
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[0]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[0]
            try:
                assert move_name == 'SETTING' and move_idx == "'OPEN_SETTINGS'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Collectionlist(self):
        #业务类型--收藏列表
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[1]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[1]
            try:
                assert move_name == 'FAVOERITE' and move_idx == "'OPEN_FAVOR'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Playhistory(self):
        #业务类型--播放历史
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[2]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[2]
            try:
                assert move_name == 'HISTORY' and move_idx == "'OPEN_HISTORY'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Search(self):
        #业务类型--搜索
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[3]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[3]
            try:
                assert move_name == 'SEARCH' and move_idx == "'OPEN_SEARCH'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_About(self):
        #业务类型--版本信息
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[4]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[4]
            try:
                assert move_name == 'ABOUT' and move_idx == "'OPEN_ABOUT_US'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Recent(self):
        #业务类型--最近观看
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[5]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[5]
            try:
                assert move_name == 'RECENT' and move_idx == "'OPEN_LAST_PLAY'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Center(self):
        #业务类型--个人中心
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[6]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[6]
            try:
                assert move_name == 'CENTER' and move_idx == "'OPEN_USER_CENTER'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_type_Player(self):
        #业务类型--播放页面
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][1]['contentList']
            move_name = re.findall(".*?'serviceType': '(.*?)'", str(program))[7]
            move_idx = re.findall(".*?'action': (.*?),", str(program))[7]
            try:
                assert move_name == 'PLAYER' and move_idx == "'OPEN_PLAYER'"
                logger.info('Test pass.action:%s'%move_idx)
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_Move(self):
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            self.Change_name()
            try:
                assert self.move_name == '行者' and self.move_idx == "'OPEN_DETAIL'"
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def get_four(self):
        program = self.ret_js["retMsg"]['remdList'][0]['remmendList'][0]['contentList']
        self.move_name = re.findall(".*?'showName': '(.*?)'", str(program))[1]
        self.move_idx = re.findall(".*?'idx': (.*?),", str(program))[1]
        logger.info(self.move_name,self.move_idx)
        # return self.move_name,self.move_idx

    def Moveto_two(self):
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            self.get_four()
            try:
                assert self.move_name == '行者' and self.move_idx == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Moveto_top(self):
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            self.get_four()
            try:
                assert self.move_name == '小猪威比' and self.move_idx == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def JsEpg5_edit(self):
        self.JsEpg5()
        homepage = HomePage(self.driver)
        device_id = self.ret_js["retCode"]
        if device_id == '00000000':
            self.Change_name()
            try:
                assert self.move_name == test_name + '（编辑）' and self.move_idx == "'OPEN_DETAIL'"
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def App_recommend(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        App_recommend_URL = config.get("testServer", "App_recommend_URL")
        logger.info("The test server url is: %s" % App_recommend_URL)
        get_url = urllib.request.urlopen(App_recommend_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_app = json.loads(Code)
        return self.ret_app

    def add_app(self):
        #置顶
        self.App_recommend()
        homepage = HomePage(self.driver)
        device_id = self.ret_app["retCode"]
        if device_id == '00000000':
            program = self.ret_app["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == test_name
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def set_down(self):
        #置底
        self.App_recommend()
        homepage = HomePage(self.driver)
        device_id = self.ret_app["retCode"]
        if device_id == '00000000':
            program = self.ret_app["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[2]
            try:
                assert add_to == test_name + '（编辑）'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def edit_app(self):
        self.App_recommend()
        homepage = HomePage(self.driver)
        device_id = self.ret_app["retCode"]
        if device_id == '00000000':
            program = self.ret_app["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == test_name + '（编辑）'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def del_app(self):
        homepage = HomePage(self.driver)
        self.App_recommend()
        device_id = self.ret_app["retCode"]
        if device_id == '00000000':
            retmsg = self.ret_app["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(retmsg))[0]
            try:
                assert add_to != test_name
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def User_wallpaper(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        user_wallpaper_URL = config.get("testServer", "user_wallpaper_URL")
        logger.info("The test server url is: %s" % user_wallpaper_URL)
        get_url = urllib.request.urlopen(user_wallpaper_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_wall = json.loads(Code)
        return self.ret_wall

    def add_wallpaper(self):
        self.User_wallpaper()
        homepage = HomePage(self.driver)
        device_id = self.ret_wall["retCode"]
        if device_id == '00000000':
            program = self.ret_wall["retMsg"]['listInfo']
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == '5.jpg'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Association(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Association_URL = config.get("testServer", "Association_URL")
        logger.info("The test server url is: %s" % Association_URL)
        get_url = urllib.request.urlopen(Association_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)
        # return ret_ass

    def get_need(self):
        program = self.ret_ass["retMsg"]
        self.add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
        self.display = re.findall(".*?'displayIndex': (.*?),", str(program))[0]
        # return add_to,display

    def ass_recommend(self):
        self.Association()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[2]
            # display = re.findall(".*?'displayIndex': (.*?),", str(program))[2]
            try:
                assert add_to == test_name
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def ass_top(self):
        self.Association()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            self.get_need()
            try:
                assert self.add_to == test_name and self.display == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def ass_down(self):
        self.Association()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            self.add_to = re.findall(".*?'name': '(.*?)'", str(program))[2]
            self.display = re.findall(".*?'displayIndex': (.*?),", str(program))[2]
            try:
                assert self.add_to == test_name and self.display == '3'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def ass_edit(self):
        self.Association()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            self.get_need()
            try:
                assert self.add_to == test_name+'（编辑）' and self.display == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def ass_delete(self):
        self.Association()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to != test_name
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Order_page(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Order_page_URL = config.get("testServer", "Order_page_URL")
        logger.info("The test server url is: %s" % Order_page_URL)
        get_url = urllib.request.urlopen(Order_page_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Order_recommend(self):
        self.Order_page()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[1]
            display = re.findall(".*?'displayIndex': (.*?),", str(program))[1]
            try:
                assert add_to == test_name and display == '3'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Order_top(self):
        self.Order_page()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            self.get_need()
            try:
                assert self.add_to == test_name and self.display == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Order_edit(self):
        self.Order_page()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            self.get_need()
            try:
                assert self.add_to == test_name+'（编辑）' and self.display == '1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Order_delete(self):
        self.Order_page()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to != test_name
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Bound_business(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Bound_business_URL = config.get("testServer", "Bound_business_URL")
        logger.info("The test server url is: %s" % Bound_business_URL)
        get_url = urllib.request.urlopen(Bound_business_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Switchover_combination(self):
        #终端切换业务组合接口测试（切换前）
        self.Bound_business()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['serviceGroupList']
            add_to = re.findall(".*?'serviceComboCode': '(.*?)'", str(program))[0]
            try:
                assert add_to == '1100121023874101446610014'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Bound_recommend(self):
        self.Bound_business()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['serviceGroupList']
            add_to = re.findall(".*?'serviceGroupCode': '(.*?)'", str(program))[0]
            try:
                assert add_to == '1100122106606149861830002'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def FJLT_Bound_recommend(self):
        self.Bound_business()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['serviceGroupList']
            add_to = re.findall(".*?'serviceGroupCode': '(.*?)'", str(program))[0]
            try:
                assert add_to == '1100122023874084936460012'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def FJLT_domainCode(self):
        # 分发域调序接口
        self.Bound_business()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]
            add_to = re.findall(".*?'domainCode': '(.*?)'", str(program))[0]
            logger.info(add_to)
            sp = re.split(',', add_to)[0]
            logger.info(sp)
            try:
                assert sp == '2100090106975227179280047'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def ks_business(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        KS_business_URL = config.get("testServer", "KS_business_URL")
        logger.info("The test server url is: %s" % KS_business_URL)
        get_url = urllib.request.urlopen(KS_business_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def KSwitchover_combination(self):
        #终端切换业务组合接口测试(切换后)
        self.ks_business()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['serviceGroupList']
            add_to = re.findall(".*?'serviceComboCode': '(.*?)'", str(program))[0]
            try:
                assert add_to == '1100121106610433378200087'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()


    def Task_Upgrade(self):
        mac_name = open(os.path.abspath('..') + '\\Downloads\\mac.txt').read()
        Upgrade_task_URL = 'http://10.3.1.107:8802/oms_api/device!deviceUpgrade?mac='+mac_name+'&comboCode=1100121023874101446610014'
        logger.info("The test server url is: %s" % Upgrade_task_URL)
        get_url = urllib.request.urlopen(Upgrade_task_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Task_recommend_up(self):
        self.Task_Upgrade()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['listInfo']
            add_to = re.findall(".*?'versionSeq': '(.*?)'", str(program))[0]
            try:
                assert add_to == '729'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Task_recommend_down(self):
        self.Task_Upgrade()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        retmsg = self.ret_ass["retMsg"]
        try:

            assert retmsg == "无对应数据" and device_id == 'A0000000'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def Page_type(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Page_type_URL = config.get("testServer", "Page_type_URL")
        logger.info("The test server url is: %s" % Page_type_URL)
        get_url = urllib.request.urlopen(Page_type_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Page_recommend(self):
        self.Page_type()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['listInfo']
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == 'Wallpaper testing0'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Page_type1(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Page_type_URL1 = config.get("testServer", "Page_type_URL1")
        logger.info("The test server url is: %s" % Page_type_URL1)
        get_url = urllib.request.urlopen(Page_type_URL1).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Page_recommend1(self):
        self.Page_type1()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['listInfo']
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == 'Wallpaper testing1'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Page_type2(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Page_type_URL2 = config.get("testServer", "Page_type_URL2")
        logger.info("The test server url is: %s" % Page_type_URL2)
        get_url = urllib.request.urlopen(Page_type_URL2).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def Page_recommend2(self):
        self.Page_type2()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['listInfo']
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == 'Wallpaper testing2'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def price_tag_wallpaper(self):
        config = configparser.ConfigParser()
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Tag_wallpaper_URL = config.get("testServer", "Tag_wallpaper_URL")
        logger.info("The test server url is: %s" % Tag_wallpaper_URL)
        get_url = urllib.request.urlopen(Tag_wallpaper_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_ass = json.loads(Code)

    def price_tag_recommend(self):
        self.price_tag_wallpaper()
        homepage = HomePage(self.driver)
        device_id = self.ret_ass["retCode"]
        if device_id == '00000000':
            program = self.ret_ass["retMsg"]['listInfo']
            add_to = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert add_to == 'The price tag test'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def get_corner(self):
        corner = 'http://10.3.1.107:8804/vod_api/assetList!getProductList?serviceGroupCode=1100122106415165314610003&packageCodes=2100130106975140035940001&pageLimit=200&pageNum=0&isAll=1'
        logger.info("The test server url is: %s" % corner)
        get_url = urllib.request.urlopen(corner).read()
        Code = get_url.decode('utf-8')
        self.ret_corner = json.loads(Code)

    def superscript(self):
        self.get_corner()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['corners'][1]
            try:
                assert program == 'http://113.208.112.134:4869/efb2813e0e5810798285c3a900ec736c'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def top_left_corner(self):
        self.get_corner()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['corners'][0]
            try:
                assert program == 'http://113.208.112.134:4869/d9d0647a4000fcdeb2e0067596d09659'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def upper_right_corner(self):
        self.get_corner()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['corners'][1]
            try:
                assert program == 'http://images.aliyun.ott.guttv.cibntv.net/e83575844b673720db4da30d57fcd3a8'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def lower_right_corner(self):
        self.get_corner()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['corners'][2]
            try:
                assert program == 'http://images.aliyun.ott.guttv.cibntv.net/560418dc2cf003516b4358d33116da18'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def lower_left_corner(self):
        self.get_corner()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['corners'][3]
            try:
                assert program == 'http://images.aliyun.ott.guttv.cibntv.net/bb97ac556d0018a83ebbadfaed44973f'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def get_package_url(self):
        corner = 'http://10.3.1.107:8801/bms_api/price!getPackagePricing?serviceComboCode=1100121022149038548320021&serviceGroupCode=1100122022055962258270018&packageCode=2100130022392381135061416&authType=0&authCode=1300110023465848762820066&token=0'
        logger.info("The test server url is: %s" % corner)
        get_url = urllib.request.urlopen(corner).read()
        Code = get_url.decode('utf-8')
        self.pak_corner = json.loads(Code)

    def Get_package_tag(self):
        """获取产品包价签订购"""
        homepage = HomePage(self.driver)
        self.get_package_url()
        device_id = self.pak_corner["retCode"]
        if device_id == '00000000':
            program = self.pak_corner["retInfo"]['isOrder']
            try:
                assert program == 1
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Unsubscribe(self):
        """获取产品包价签退订"""
        homepage = HomePage(self.driver)
        self.get_package_url()
        device_id = self.pak_corner["retCode"]
        if device_id == '00000000':
            program = self.pak_corner["retInfo"]['isOrder']
            try:
                assert program == 0
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def DhBrowser(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        DH_tx = config.get("testServer", "DH_tx")
        logger.info("The test server url is: %s" % DH_tx)
        get_url = urllib.request.urlopen(DH_tx).read()
        self.Code = get_url.decode('utf-8')
        self.ret_tx = json.loads(self.Code)
        return self.ret_tx

    def DH_tx_browser(self):
        '''一个产品包下线'''
        homepage = HomePage(self.driver)
        self.DhBrowser()
        device_id = self.ret_tx["retCode"]
        if device_id == '00000000':
            prod = re.findall('.*?"productName":"(.*?)"', self.Code)
            join = ''.join(prod)
            try:
                assert join == '大话天仙'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def DH_tx_downline(self):
        '''两个产品包下线'''
        homepage = HomePage(self.driver)
        self.DhBrowser()
        device_id = self.ret_tx["retCode"]
        if device_id == 'A0000000':
            retmsg = self.ret_tx["retMsg"]
            try:
                assert retmsg == '无对应数据'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def PackageInfo(self):
        Upgrade_task_URL = 'http://10.3.1.107:8804/vod_api/packageInfo!getPackageInfoByCode?serviceGroupCode=1100122022055962258270018&packageCode=2100130106567050420160636&pageLimit=100&pageNum=0'
        logger.info("The test server url is: %s" % Upgrade_task_URL)
        get_url = urllib.request.urlopen(Upgrade_task_URL).read()
        Code = get_url.decode('utf-8')
        self.ret_pack = json.loads(Code)


    def getPackageInfo(self):
        self.PackageInfo()
        homepage = HomePage(self.driver)
        device_id = self.ret_pack["retCode"]
        if device_id == '00000000':
            program = self.ret_pack["retMsg"]
            add_to = re.findall(".*?'pictureUrl': '(.*?)'", str(program))[0]
            addre = re.split('\?', add_to)[-1]
            try:
                assert addre == img_url
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def PackageInfoByCode(self):
        self.PackageInfo()
        homepage = HomePage(self.driver)
        device_id = self.ret_pack["retCode"]
        if device_id == '00000000':
            program = self.ret_pack["retMsg"]
            add_to = re.findall(".*?'pictureUrl': '(.*?)'", str(program))[0]
            addre = re.split('\?', add_to)[-1]
            try:
                assert addre != img_url
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Sequence_number(self):
        self.PackageInfo()
        homepage = HomePage(self.driver)
        device_id = self.ret_pack["retCode"]
        if device_id == '00000000':
            program = self.ret_pack["retMsg"]['listInfo'][0]['innerSeq']
            # add_to = re.findall(".*?'innerSeq': '(.*?)'", str(program))[0]
            # addre = open('D:\\package.txt').read()
            addre = open(os.path.abspath('..'+ "\\Downloads\\number.txt")).read()
            try:
                assert addre == str(program)
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Tree_state1(self):
        config = configparser.ConfigParser()  # 创建一个管理对象
        file_path = os.path.dirname(os.path.abspath('.')) + '/config/config.ini'
        config.read(file_path)
        Tree_state_URL1 = config.get("testServer", "Tree_state_URL1")
        logger.info("The test server url is: %s" % Tree_state_URL1)
        get_url = urllib.request.urlopen(Tree_state_URL1).read()
        Code = get_url.decode('utf-8')
        self.ret_tree = json.loads(Code)
        return self.ret_tree

    def Tree_enable1(self):
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][1]
            name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            sub = self.ret_tree["retMsg"][2]
            subsection = re.findall(".*?'name': '(.*?)'", str(sub))[0]
            try:
                assert name == '电影' and subsection == '国产大片'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Tree_disable(self):
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][1]
            name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            sub = self.ret_tree["retMsg"][2]
            subsection = re.findall(".*?'name': '(.*?)'", str(sub))[0]
            try:
                assert name == '电视剧' and subsection == '热播大剧'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Tree_Subsection(self):
        """添加子栏目接口"""
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][1]
            name = re.findall(".*?'name': '(.*?)'", str(program))[2]
            # sub = self.ret_tree["retMsg"][2]
            # subsection = re.findall(".*?'name': '(.*?)'", str(sub))[0]
            try:
                assert name == '子栏目'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Binding_tree1(self):
        #栏目树产品包绑定栏目树测试
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][3]
            name = re.findall(".*?'packageCodes': '(.*?)'", str(program))[1]
            try:
                assert name == '2100130106505373510770058'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Unbundling_tree1(self):
        #栏目树产品包解绑栏目树测试
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][3]
            name = re.findall(".*?'packageCodes': '(.*?)'", str(program))[0]
            try:
                assert name == ''
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def tree_edit(self):
        """编辑"""
        homepage = HomePage(self.driver)
        self.Tree_state1()
        device_id = self.ret_tree["retCode"]
        if device_id == '00000000':
            program = self.ret_tree["retMsg"][1]
            name = re.findall(".*?'name': '(.*?)'", str(program))[0]
            try:
                assert name == '电影（编辑）'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def order(self):
        #产品调序接口
        corner = 'http://10.3.1.107:8804/vod_api/assetList!getProductList?serviceGroupCode=1100122106559369607370027&packageCodes=2100130106719367151270277&pageLimit=200&pageNum=0&isAll=1'
        logger.info("The test server url is: %s" % corner)
        get_url = urllib.request.urlopen(corner).read()
        Code = get_url.decode('utf-8')
        self.ret_corner = json.loads(Code)

    def Product_order(self):
        self.order()
        homepage = HomePage(self.driver)
        device_id = self.ret_corner["retCode"]
        if device_id == '00000000':
            program = self.ret_corner["retMsg"]['listInfo'][0]['productName']
            try:
                assert program == '爱情保卫战 高清'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()

    def Upgrade(self):
        Upgrade_URL = 'http://10.3.1.107:8802/oms_api/device!version?apkName=EPG-FJLT4.0.200-20170420-BASE&mac=20:8b:37:39:cb:42&apkMD5=CF3430797ABD1E5D3BEE15E639E0648C&type=3&serviceComboCode=1100121023874101446610014&version='
        num = random.randint(300, 400)
        upgradeurl = Upgrade_URL + str(num)
        logger.info("The test server url is: %s" % upgradeurl)
        get_url = urllib.request.urlopen(upgradeurl).read()
        Code = get_url.decode('utf-8')
        self.upgrade = json.loads(Code)
        return num

    def Upgrade_report(self):
        self.Upgrade()
        homepage = HomePage(self.driver)
        device_id = self.upgrade["retCode"]
        if device_id == '00000000':
            program = self.upgrade["retMsg"]
            try:
                assert program == 'APK版本上报处理成功.'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
        else:
            homepage.get_windows_img()






