# coding=utf-8
import unittest,time,os,re,xlrd,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from Vod_Content_management.EpisodesList import VodSearch
from framework.Interface_test import Interface
from framework.logger import Logger

logger = Logger(logger="BrowserEngine").getlog()
product_api_name = '测试产品包专用'
display_name = '测试专用'
rand = random.randint(0, 100)
product_api_names = product_api_name+str(rand)
#产品包列表


class Product(unittest.TestCase,Interface):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_Newly_added(self):
        """产品包新增"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()        #产品管理
        homepage.custom_toolbar()        #新增
        homepage.sr_mingchen(product_api_names)   #输入名称
        homepage.sr_zs_mingchen(display_name)   #输入展示名称
        homepage.xz_chanping()      #选择产品
        product_name = driver.find_element_by_xpath('//*[@id="unSelectedProductTable"]/tbody/tr[6]/td[2]').text# 产品包-产品管理-选择产品名称
        cp_name = driver.find_element_by_xpath('//*[@id="unSelectedProductTable"]/tbody/tr[6]/td[4]').text  # 产品包-产品管理-选择cp名称
        homepage.cp_mingchen(product_name)      #输入产品名称
        homepage.sr_chanp()     #点击CP下拉框
        homepage.sr_cp_mingchen(cp_name)    #输入cp名称
        homepage.sr_cp_mingchen(Keys.ENTER)
        homepage.dj_duig()      #点击对勾
        homepage.prd_add()      #点击右箭头
        select = driver.find_element_by_xpath('//*[@id="selectedProductTable"]/tbody/tr/td[2]').text
        cp_select = driver.find_element_by_xpath('//*[@id="selectedProductTable"]/tbody/tr/td[4]').text
        try:
            assert select == product_name and cp_select == cp_name
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()  # 调用基类截图方法
        homepage.pd_dialog()        #点击清除筛选
        none = driver.find_element_by_xpath('//*[@id="productName"]').text  #匹配‘输入产品名称框’
        cps = driver.find_element_by_xpath('//*[@id="product_dialog"]/div/div/div[2]/div[1]/div[1]/div[1]/div[2]/label[2]/div/button/span[1]').text  #匹配‘输入产品名称框’
        try:
            assert none == '' and cps == '全部'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()  # 调用基类截图方法
        homepage.btnSaves()      #确认按钮
        currenttime = time.strftime("%Y-%m-%d %H:%M", time.localtime())
        logger.info('The current time is:%s' % currenttime)
        Select(self.driver.find_element_by_id('create_pkg_type')).select_by_value('1')  # 包类型选择专题包
        driver.find_element_by_id('create_pictureurl1File').send_keys(os.path.abspath('..') + "\\picture\\3.jpg")   #上传图片
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="create_package_form"]/div[7]/div/div/div[3]/div[2]/a/span').click()#点击上传
        time.sleep(3)
        homepage.btnCreat()     #点击保存按钮
        try:
            assert VodSearch.get_ass_text(self) == '创建操作成功!'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.',format(e))
            homepage.get_windows_img()
        homepage.confirm_1()        #确认按钮
        """产品打包时间"""
        homepage.searchBtn()        #点击搜索
        homepage.add_names(product_api_names)       #输入搜索名称
        homepage.searchByName()                #点击搜索按钮
        homepage.dj_shangxx()                #点击编辑
        homepage.chooseProduct()                #点击选择产品
        packingtime = driver.find_element_by_xpath('//*[@id="selectedProductTable"]/tbody/tr/td[7]').text
        pack0 = packingtime.split(':')[0]
        pack1 = packingtime.split(':')[1]
        get_time = pack0 + ':' + pack1
        logger.info('The time to get is:%s'%get_time)
        try:
            assert get_time == currenttime
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.',format(e))
            homepage.get_windows_img()
        homepage.btnSaves()  #  确认
        driver.find_element_by_xpath('//*[@id="edit_package_form"]/div[12]/div/button[2]').click()   #  点击关闭
        time.sleep(1)
        search_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        try:
            assert search_name == product_api_names
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.',format(e))
            homepage.get_windows_img()
        homepage.searchReset()      #点击重置

    def test_Product_up(self):
        """产品包上线"""
        homepage = HomePage(self.driver)
        driver = self.driver
        Select(driver.find_element_by_id('isLine')).select_by_value('0')  # 在线状态选择待上线
        time.sleep(5)
        # old_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 获取初始名称
        # time.sleep(2)
        homepage.table_2()  # 点击编辑
        homepage.package_name('(上线测试)')  # 名称添加字段
        homepage.edit_package_tag('测试')#添加产品标签
        homepage.edit_package_form()  # 点击保存
        # 判断是否操作编辑是否成功
        try:
            assert VodSearch.get_ass_text(self) == '编辑操作成功!'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()  # 调用基类截图方法
        time.sleep(2)
        homepage.confirm_1()  # 点击编辑确定
        up_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 匹配待上线名称
        homepage.send_submit_btn()      #点击上线
        try:
            assert VodSearch.get_ass_text(self) == '上线操作成功!'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.confirm_1()            #点击确认
        homepage.add_names(up_name)  # 通过xpath定位输入框，send_keys传值到输入框
        Select(driver.find_element_by_id('isLine')).select_by_visible_text('全部')  # 审核下拉框并选择全部
        time.sleep(2)
        homepage.searchByName()  # 点击搜索
        test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        test1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[8]').text
        try:
            assert test == up_name and test1 == '上线'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.searchReset()  # 重置

    def test_Product_down(self):
        """产品包下线"""
        homepage = HomePage(self.driver)
        driver = self.driver
        Select(driver.find_element_by_id('isLine')).select_by_value('1')  # 在线状态选择上线
        time.sleep(5)
        # old_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 获取初始名称
        # time.sleep(2)
        homepage.edit_product()  # 点击编辑
        homepage.package_name('(下线测试)')  # 名称添加字段
        homepage.edit_package_form()  # 点击保存
        # 判断是否操作编辑是否成功
        try:
            assert VodSearch.get_ass_text(self) == '编辑操作成功!'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()  # 调用基类截图方法
        time.sleep(2)
        homepage.confirm_1()  # 点击编辑确定
        up_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 匹配待上线名称
        homepage.send_submit_btn()      #点击下线
        try:
            assert VodSearch.get_ass_text(self) == '下线操作成功!'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.confirm_1()            #点击确认
        homepage.add_names(up_name)  # 通过xpath定位输入框，send_keys传值到输入框
        Select(driver.find_element_by_id('isLine')).select_by_visible_text('全部')  # 审核下拉框并选择全部
        time.sleep(2)
        homepage.searchByName()  # 点击搜索
        test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        test1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[8]').text
        try:
            assert test == up_name and test1 == '下线'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.searchReset()  # 重置

    def jsyd_product_num(self):
        driver = self.driver
        driver.execute_script("window.scrollBy(0,500)")
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[12]/td[2]/a[2]/i').click()  # 点击江苏移动详情
        time.sleep(2)
        driver.execute_script("window.scrollBy(0,500)")
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="product_2100050106276448857110073"]/i').click()  # 点击产品包数量
        time.sleep(2)

    def test_Special_poster(self):
        """专题海报"""
        """上传"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        # homepage.dj_chanpguanl()  # 产品管理
        # homepage.searchBtn()  # 点击搜索
        driver = self.driver
        homepage.add_names('专题海报接口测试')  # 输入搜索内容
        homepage.add_names(Keys.ENTER)
        homepage.special_poster()  #  专题海报
        homepage.spec_table()  #  点击上传
        driver.find_element_by_id('spec_pictureurl1File').send_keys(os.path.abspath('..') + "\\picture\\4.jpg")  # 上传图片
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="spec_poster"]/div/div/div[2]/div[1]/div[3]/div[2]/a/span').click()  # 点击上传
        time.sleep(3)
        try:
            assert VodSearch.get_ass_text(self) == '专题海报更新成功'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.button_1()   #  确认
        # time.sleep(50)
        # Interface.getPackageInfo(self)        #   添加海报接口
        """删除"""
        homepage.spec_input_table()  #  点击复选
        driver.find_element_by_css_selector('html body div#main.container-fluid div.row div#body_right.col-sm-9.col-sm-offset-3.col-md-10.col-md-offset-2.main div#spec_pkg_pic.modal.fadein.in div.modal-dialog.modal-lg div.modal-content div.modal-body div#custom-toolbar div.form-inline button.btn.btn-warning').click()  #  删除
        time.sleep(1)
        try:
            assert VodSearch.get_ass_text(self) == '删除专题海报成功'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.button_1()   #  确认
        # time.sleep(60)
        # Interface.PackageInfoByCode(self)    #删除海报接口
        old_name = driver.find_element_by_xpath('//*[@id="spec_table"]/tbody/tr/td[4]').text
        try:
            assert old_name == ''
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        """序号调序接口"""
        driver.find_element_by_xpath('//*[@id="spec_table"]/tbody/tr/td[4]/input').clear()  #  清空序号
        rand = random.randint(1,20)
        driver.find_element_by_xpath('//*[@id="spec_table"]/tbody/tr/td[4]/input').send_keys(str(rand))  #  输入序号
        time.sleep(2)
        with open(os.path.abspath('..'+ "\\Downloads\\number.txt"), 'w', encoding='utf-8') as ff:
            ff.write(str(rand))
        driver.find_element_by_xpath('//*[@id="spec_pkg_pic"]/div/div/div[2]/div[5]/button[1]').click() #  点击刷新
        # time.sleep(80)
        # Interface.Sequence_number(self)
        homepage.spec_pkg_pic()   #  关闭

    def delete(self):
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.productPkg()  # 关闭
        homepage.dj_chanpguanl()  # 产品管理
        homepage.searchBtn()  # 点击搜索
        homepage.add_names(product_api_names)  # 输入搜索内容
        homepage.add_names(Keys.ENTER)
        homepage.delete_an()
        driver.switch_to_alert().accept()  # 点击弹出里面的确定按钮
        try:
            assert VodSearch.get_ass_text(self) == '删除成功！'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.confirm_1()
        homepage.searchByName()  # 点击搜索
        text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td').text  # 没有找到匹配的记录
        try:
            assert text == '没有找到匹配的记录'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.searchReset()  # 重置

    def test_delete(self):
        """产品包删除"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.column_M()  # 点击栏目管理
        self.jsyd_product_num()
        homepage.cleanProduct()  # 清空
        driver.switch_to_alert().accept()
        # time.sleep(2)
        try:
            dis = driver.find_element_by_xpath('/html/body/div[7]/div/div/div[3]/button').is_displayed()
            assert dis
            homepage.button_1()  # 确认 （自动化时没有弹出框）
            self.delete()
        except:
            self.delete()

    def test_Search(self):
        """搜索"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()#点击产品管理
        # homepage.searchBtn()#点击搜索
        initial_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 获取初始名称
        cp_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[9]').text  # 获取包类型
        homepage.add_names(initial_name)
        Select(driver.find_element_by_id('type1')).select_by_visible_text(cp_name)  # 审核下拉框并选择全部
        time.sleep(2)
        homepage.searchByName()  # 点击搜索
        test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        type = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[9]').text
        try:
            assert test == initial_name and type == cp_name
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        """标签关键字"""
        homepage.searchReset()  # 重置
        homepage.tagKey('测试')  # 输入关键字
        homepage.tagKey(Keys.ENTER)
        Test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[12]').text
        try:
            assert Test == '测试'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        """专题包展示类型"""
        homepage.searchReset()  # 重置
        Select(driver.find_element_by_id('type1')).select_by_value('1')  #  选择专题包
        time.sleep(1)
        template = ['TEMPLATE_ZERO', 'TEMPLATE_A', 'TEMPLATE_B', 'TEMPLATE_C','TEMPLATE_D','TEMPLATE_E']
        for temp in template:
            Select(driver.find_element_by_id('templType')).select_by_value(temp)  # 选择 产品
            time.sleep(1)
            template_zero = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[10]').text
            logger.info('template_zero is:%s'%template_zero)
            try:
                assert template_zero == '默认模板' or template_zero == '模板一' or template_zero == '模板二' or template_zero == '模板三' or template_zero == '模板四' or template_zero == '模板五'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()

    def test_Reset(self):
        """重置"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.searchReset()
        test = driver.find_element_by_xpath('//*[@id="name"]').text
        select = driver.find_element_by_xpath('//*[@id="type1"]/option[1]').text
        try:
            assert test == '' and select == '全部'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    def test_Sheet_export(self):
        """片单导出"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()  # 产品管理
        Select(driver.find_element_by_id('isLine')).select_by_value('1')      # 在线状态下拉框并选择上线
        time.sleep(2)
        initial = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text   #获取初始名称
        homepage.table_input()      #点击对勾
        driver.find_element_by_xpath('//*[@id="exportBtn"]').click()        #点击片单导出
        # homepage.dc_shuju()     #数据导出
        try:
            assert VodSearch.get_ass_text(self) == '创建成功'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.confirm_1()        #确认
        homepage.jc_peizhi()        #基础配置
        homepage.collapseThree()    #任务查询
        new_text = driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[3]').text
        try:
            assert new_text == '产品包：'+initial+'_详单导出' or new_text == '产品包：' +initial+ '...详单导出'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        """下载"""
        time.sleep(50)
        driver.refresh()
        http = driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[2]/a').get_attribute('href')  # 获取href
        sp = re.split('/', http)[-1]
        logger.info(sp)
        driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[2]/a/i').click()
        time.sleep(3)
        wb = xlrd.open_workbook('C:\\Users\\范凯森\\Downloads\\' + sp + '')
        mysheet = wb.sheet_names()
        # tab = wb.sheet_by_name(mysheet[0])
        # data = tab.col_values(0)[1]
        logger.info(mysheet[0])
        try:
            assert mysheet[0] == '产品包导出节目详情'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_Online_status(self):
        """在线状态"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()
        Select(driver.find_element_by_id('isLine')).select_by_value('0')# 在线状态下拉框并选择待上线
        time.sleep(2)
        On_line = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text
        try:
            assert On_line == '待上线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_value('2')#选择下线
        time.sleep(3)
        Offline = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text
        try:
            assert Offline == '下线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_value('1')#上线
        time.sleep(3)
        Go_online = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text
        try:
            assert Go_online == '上线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_visible_text('全部')  # 审核下拉框并选择全部
        time.sleep(2)

    def test_package_copy(self):
        """产品包复制"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 产品管理
        # homepage.coLLapseTwo()   # 点击产品包列表
        homepage.searchBtn()   # 点击搜索
        homepage.add_names(product_api_names+'接口测试')  #   输入搜索内容
        homepage.add_names(Keys.ENTER)
        cp_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[1]/input').click()  #
        time.sleep(1)
        homepage.copyBtn()  #  点击产品包复制
        try:
            assert VodSearch.get_ass_text(self) == '产品包复制中'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.confirm_1()  #  确认
        copy_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        try:
            assert copy_name == cp_name + '_复制'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.send_submit_btn()  #  点击上线
        homepage.confirm_1()  #  点击确认
        code = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text
        with open('D:\\codes.txt', 'w', encoding='utf-8') as ff:
            ff.write(code)
        homepage.column_M()  # 点击栏目管理
        self.jsyd_product_num()
        homepage.packageSearchText(product_api_names + '接口测试_复制')  # 输入产品名称
        homepage.btnPkgSearch()  # 点击搜索
        driver.find_element_by_xpath('//*[@id="libPkgTable"]/tbody/tr/td[1]/input').click()  # 点击复选
        homepage.prd_add()  # 向右追加
        homepage.bindProduct()  # 点击确认
        homepage.confirm_1()  # 确认
        homepage.dj_chanpguanl()  # 产品管理
        homepage.searchBtn()  # 点击搜索
        homepage.add_names(product_api_names + '接口测试')  # 输入搜索内容
        homepage.add_names(Keys.ENTER)
        homepage.send_submit_btn()  #  点击下线
        homepage.confirm_1()  #  确认
        time.sleep(80)
        Interface.DH_tx_browser(self)       #一个产品包下线
        homepage.upMovebtn()  #  点击上线
        homepage.confirm_1()  # 确认
        time.sleep(120)
        Interface.DH_tx_downline(self)  #   两个产品包下线
        homepage.bo_right()  #  点击全部复选
        homepage.online_1()  #  点击上线
        homepage.confirm_1()  #  确认
        homepage.column_M()  # 点击栏目管理
        self.jsyd_product_num()
        # homepage.productPkg_input()    #  点击全部复选
        # homepage.prd_Remove()    #
        homepage.cleanProduct()  #  清空
        driver.switch_to_alert().accept()
        homepage.button_1()  # 确认
        homepage.productPkg()  #  关闭
        homepage.dj_chanpguanl()  # 产品管理
        homepage.searchBtn()  # 点击搜索
        homepage.add_names(product_api_names + '接口测试')  # 输入搜索内容
        homepage.add_names(Keys.ENTER)
        homepage.bo_right()    #  点击全部复选
        homepage.custom4_toolbar()    #  点击删除
        driver.switch_to_alert().accept()
        homepage.confirm_1()  # 确认

    def test_package_interface(self):
        """产品包接口测试"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 产品管理
        homepage.custom_toolbar()  # 新增
        homepage.sr_mingchen(product_api_names+'接口测试')  # 输入名称
        homepage.sr_zs_mingchen(display_name)  # 输入展示名称
        homepage.xz_chanping()  # 选择产品
        homepage.cp_mingchen('厉害了我的歌 高清')  #  输入产品名称
        homepage.sr_chanp()  # 点击CP下拉框
        homepage.sr_cp_mingchen('天脉')  # 输入cp名称
        homepage.sr_cp_mingchen(Keys.ENTER)
        homepage.dj_duig()  # 点击复选
        homepage.prd_add()  # 点击右箭头
        homepage.btnSaves()  #  点击确认
        homepage.btnCreat()  #  点击保存
        homepage.confirm_1()  #  点击确认
        code = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text
        with open('D:\\code.txt', 'w', encoding='utf-8') as ff:
            ff.write(code)
        state = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text
        if state != '上线':
            homepage.table_input()  #  点击复选
            homepage.online_1()  #  点击上线
            homepage.confirm_1()  #  点击确认
            homepage.column_M()  #  点击栏目管理
            # driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[10 ]/td[2]/a[2]/i').click()  #  点击江苏移动详情
            driver.execute_script("window.scrollBy(0,500)")
            time.sleep(1)
            driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[12]/td[2]/a[2]/i').click()  #  点击江苏移动详情
            time.sleep(2)
            driver.execute_script("window.scrollBy(0,500)")
            time.sleep(1)
            driver.find_element_by_xpath('//*[@id="product_2100050106276448857110073"]/i').click()  #  点击产品包数量
            time.sleep(2)
            homepage.packageSearchText(product_api_names+'接口测试')  #  输入产品名称
            homepage.btnPkgSearch()  #  点击搜索
            driver.find_element_by_xpath('//*[@id="libPkgTable"]/tbody/tr/td[1]/input').click()  #  点击复选
            homepage.prd_add()  #  向右追加
            homepage.bindProduct()  #  点击确认
            homepage.confirm_1()  #  确认
            # time.sleep(160)
            # Interface.Product_downline(self)

    def test_Product_interface(self):
        """产品加入产品包接口测试"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 点击产品管理
        homepage.collapseOne()  # 点击产品列表
        homepage.searchBtn()  # 点击搜索
        homepage.add_names('大话天仙')  # 输入产品名称
        homepage.cp_dianji()  # 点击cp下拉
        homepage.cp_shuru('4K花园')  # 输入cp名称
        homepage.cp_shuru(Keys.ENTER)
        homepage.searchByName()  # 点击搜索
        homepage.table_Input()  # 点击复选
        driver.find_element_by_xpath('//*[@id="batchAddPkgs"]').click()  #  点击加入产品包
        homepage.s_PkgName(product_api_names+'接口测试')  #  输入产品包名称
        homepage.s_BtnSearch()  #  点击搜索
        homepage.unbindPkgTable()  #  点击复选
        homepage.add_package_dialog()  #  点击导入
        homepage.btnSaves()  #  点击确认
        alert = driver.find_element_by_xpath('//*[@id="guttv_dyn_alert"]').text
        if alert == '网络异常！':
            homepage.button_1()  #  确认
            driver.find_element_by_xpath('//*[@id="add_package_dialog"]/div/div/div[2]/div[2]/button[1]').click()
            time.sleep(1)
        else:
            assname = VodSearch.get_ass_text(self)
            ass = re.split('，',assname)[0]
            try:
                assert ass == '产品加入产品包成功'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
            homepage.confirm_1()  #  确认
        time.sleep(80)
        Interface.Binding_package(self)


    def test_Corner(self):
        """角标"""
        # VodSearch.test_Sign_in(self)
        corner = '角标(产品包)测试（勿动）'
        driver = self.driver
        homepage = HomePage(self.driver)
        homepage.dj_chanpguanl()  # 点击产品管理
        homepage.searchBtn()  # 点击搜索
        homepage.add_names(corner)  # 输入产品名称
        homepage.add_names(Keys.ENTER)
        def choice_corner():
            driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[2]/a[7]/i').click()  #  点击角标
            time.sleep(1)
            Select(driver.find_element_by_id('allServiceGroup')).select_by_value('1100122106415165314610003')  # 选择角标
        choice_corner()
        driver.find_element_by_xpath('//*[@id="corner_alone"]').click()  # 点击独播
        time.sleep(1)
        def preservation():
            driver.find_element_by_xpath('//*[@id="btnUpdateCorner"]').click()  # 点击保存
            time.sleep(1)
            driver.switch_to_alert().accept()
            try:
                assert VodSearch.get_ass_text(self) == '成功保存角标。'
                logger.info('Test pass.')
            except Exception as e:
                logger.info("Test fail.", format(e))
                homepage.get_windows_img()
            homepage.confirm_1()  # 确认
            time.sleep(80)
        preservation()
        Interface.top_left_corner(self)
        choice_corner()
        driver.find_element_by_xpath('//*[@id="corner_vip"]').click()  # 点击VIP
        time.sleep(1)
        preservation()
        Interface.upper_right_corner(self)
        choice_corner()
        driver.find_element_by_xpath('//*[@id="corner_head"]').click()  # 点击首播
        time.sleep(1)
        preservation()
        Interface.lower_right_corner(self)
        choice_corner()
        driver.find_element_by_xpath('//*[@id="corner_hot"]').click()  # 点击热播
        time.sleep(1)
        preservation()
        Interface.lower_left_corner(self)

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()





