# coding=utf-8
import unittest,time,random,re,xlrd
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from Vod_Content_management.EpisodesList import VodSearch
from framework.logger import Logger
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

ks_name = 'KS产品包测试（勿动）'
cp_name = '办公室笑花 2015'
logger = Logger(logger="BrowserEngine").getlog()
#产品列表
class List(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_Search(self):
        """搜索"""
        VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 产品管理
        homepage.collapseOne()  #产品列表
        initial_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 获取初始名称
        one_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[4]').text  # 一级分类
        cp_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[8]').text       #CP名称
        homepage.searchBtn()    #搜索按钮
        homepage.add_names(initial_name)
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[3]/div/button').click() #点击一级分类下拉
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[3]/div/div/div/input').send_keys(one_name)#输入一级分类名称
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[3]/div/div/div/input').send_keys(Keys.ENTER)#回车
        time.sleep(2)
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[5]/div/button').click()  # 点击CP下拉
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[5]/div/div/div/input').send_keys(cp_name)  # 输入cp名称
        driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[5]/div/div/div/input').send_keys(Keys.ENTER)
        time.sleep(2)
        homepage.searchByName()  # 点击搜索
        test = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        type = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[4]').text
        type1 = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[8]').text
        try:
            assert test == initial_name and type == one_name and type1 == cp_name
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    def test_Reset(self):
        """重置"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.searchReset()
        test = driver.find_element_by_xpath('//*[@id="name"]').text
        select = driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[3]/div/button/span[1]').text
        selects = driver.find_element_by_xpath('//*[@id="searchDiv"]/div/label[5]/div/button/span[1]').text
        try:
            assert test == '' and select == '全部' and selects == '全部'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()

    def test_Online_status(self):
        """在线状态"""
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()
        Select(driver.find_element_by_id('isLine')).select_by_value('0')# 在线状态下拉框并选择待上线
        time.sleep(2)
        On_line = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[7]').text
        try:
            assert On_line == '待上线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_value('2')#选择下线
        time.sleep(2)
        Offline = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[7]').text
        try:
            assert Offline == '下线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_value('1')#上线
        time.sleep(2)
        Go_online = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[7]').text
        try:
            assert Go_online == '上线'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        Select(driver.find_element_by_id('isLine')).select_by_visible_text('全部')  # 审核下拉框并选择全部
        time.sleep(2)

    def test_Es(self):
        """ES同步"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()  # 产品管理
        # homepage.collapseOne()  # 产品列表
        homepage.send_submit_btn()      #ES同步按钮
        syn = driver.find_element_by_xpath('//*[@id="guttv_dyn_alert"]').text
        chron = re.split(',', syn)[0]
        logger.info(chron)
        try:
            assert chron == '同步完毕'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.confirm_1()    #确认按钮

    def test_Edit(self):
        """编辑"""
        homepage = HomePage(self.driver)
        driver = self.driver
        old_name = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        homepage.edit_product() #点击编辑
        homepage.product_name('（编辑测试）')#添加
        homepage.edit_product_form()#点击保存
        try:
            assert VodSearch.get_ass_text(self) == '更新操作成功!'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.confirm_1()    #确认按钮
        get_text = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text
        homepage.add_names(get_text)
        homepage.searchByName()
        asst = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[3]').text
        try:
            assert asst == get_text
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.glyphicon_edit()       #点击编辑
        homepage.product_name_clear()  # 删除‘编辑测试’
        homepage.product_name(old_name)  # 添加
        homepage.edit_product_form()  # 点击保存
        homepage.confirm_1()  # 点击确认
        homepage.searchReset()  # 重置

    # def test_Export_sheet(self):
    #     """从文件导出片单"""
    #     VodSearch.test_Sign_in(self)
    #     homepage = HomePage(self.driver)
    #     driver = self.driver
    #     homepage.dj_chanpguanl()  # 产品管理
    #     homepage.collapseOne()  # 产品列表
    #     homepage.downProducts()  # 点击导出片单


    def test_Add_package(self):
        """加入产品包"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()  # 产品管理
        # homepage.collapseOne()  # 产品列表
        # homepage.searchBtn()  # 搜索按钮
        homepage.add_names(cp_name)  #  输入名称
        homepage.add_names(Keys.ENTER)  #  回车
        homepage.table_input()      #点击复选
        driver.find_element_by_xpath('//*[@id="batchAddPkgs"]').click()     #点击加入产品包
        time.sleep(2)
        homepage.s_PkgName(ks_name)
        homepage.s_BtnSearch()  #搜索按钮
        ass1 = driver.find_element_by_xpath('//*[@id="UnbindPkgTable"]/tbody/tr/td[2]').text
        try:
            assert ass1 == ks_name
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.unbindPkgTable()#点击复选
        homepage.add_package_dialog() #导入
        space1 = driver.find_element_by_xpath('//*[@id="SelPkgTable"]/tbody/tr/td[2]').text
        try:
            assert space1 == ass1
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.btnSaves()      #点击确认
        # try:
        #     assert VodSearch.get_ass_text(self) == '产品已经加入产品包中'
        #     logger.info('Test pass.')
        # except Exception as e:
        #     logger.info("Test fail.", format(e))
        #     homepage.get_windows_img()
        # homepage.confirm_1()    #确认按钮
        homepage.button_1()    #    网络异常确认
        driver.find_element_by_xpath('//*[@id="add_package_dialog"]/div/div/div[2]/div[2]/button[1]').click()
        time.sleep(1)
        homepage.coLLapseTwo()    #  点击产品包列表
        homepage.searchBtn()    #  点击搜索
        homepage.add_names(ks_name)   #  输入产品包名称
        homepage.add_names(Keys.ENTER)
        homepage.glyphicon_edit()  #  点击编辑
        homepage.chooseProduct()  #  点击选择产品
        homepage.selectedProductName(cp_name)  #  输入已选产品
        homepage.selectedProductName(Keys.ENTER)
        selected_name = driver.find_element_by_xpath('//*[@id="selectedProductTable"]/tbody/tr/td[2]').text   #  获取已选产品名称
        try:
            assert selected_name == cp_name
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        # homepage.click_duig()  #  点击复选
        # homepage.prd_Remove()  #  向左移除
        homepage.btnSaves()  #  点击确认
        homepage.edit_package_form()  #  点击保存
        homepage.confirm_1()  #  点击确认

    def test_Remove_package(self):
        """移除产品包"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()  # 产品管理
        homepage.collapseOne()  # 产品列表
        homepage.searchBtn()  # 搜索按钮
        homepage.add_names(cp_name)  # 输入名称
        homepage.add_names(Keys.ENTER)  # 回车
        homepage.table_input()  # 点击复选
        driver.find_element_by_xpath('//*[@id="batchRemovePkgs"]').click()  # 点击移出产品包
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="RemovePkgTable"]/tbody/tr/td[1]/input').click() #  点击复选
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="btnRemoveFromPackage"]').click()  #  点击移出
        time.sleep(2)
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="guttv_dyn_alert"]')))
        homepage.confirm_1()  #  确认
        homepage.coLLapseTwo()  # 点击产品包列表
        homepage.searchBtn()  # 点击搜索
        homepage.add_names(ks_name)  # 输入产品包名称
        homepage.add_names(Keys.ENTER)
        homepage.glyphicon_edit()  # 点击编辑
        homepage.chooseProduct()  # 点击选择产品
        homepage.selectedProductName(cp_name)  # 输入已选产品
        homepage.selectedProductName(Keys.ENTER)
        selected_name = driver.find_element_by_xpath('//*[@id="selectedProductTable"]/tbody/tr/td').text
        try:
            assert selected_name == '没有找到匹配的记录'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.btnSaves()  # 点击确认
        homepage.edit_package_form()  # 点击保存
        homepage.confirm_1()  # 点击确认

    def test_export(self):
        """导出"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        # homepage.dj_chanpguanl()  # 产品管理
        homepage.collapseOne()  # 产品列表
        Select(driver.find_element_by_id('isLine')).select_by_value('1')      # 在线状态下拉框并选择上线
        time.sleep(1)
        initial = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text   #获取初始名称     非常静距离 高清
        homepage.table_input()      #点击复选
        driver.find_element_by_xpath('//*[@id="exportBtn"]').click()        #点击导出
        # homepage.dc_shuju()     #数据导出
        try:
            assert VodSearch.get_ass_text(self) == '创建成功'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        homepage.confirm_1()        #确认
        homepage.jc_peizhi()        #基础配置
        homepage.collapseThree()    #任务查询
        new_text = driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[3]').text
        logger.info('sssssssssssssssssss%s'%new_text)
        try:
            assert new_text == '产品：'+initial+'_详单导出' or new_text == '产品：' +initial+ '...详单导出'
            logger.info('Test pass')
        except Exception as e:
            logger.info('Test fail.', format(e))
            homepage.get_windows_img()
        """下载"""
        time.sleep(50)
        driver.refresh()
        http = driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[2]/a').get_attribute('href')  # 获取href
        sp = re.split('/', http)[-1]
        logger.info(sp)
        driver.find_element_by_xpath('//*[@id="task_table"]/tbody/tr[1]/td[2]/a/i').click()
        time.sleep(3)
        wb = xlrd.open_workbook('C:\\Users\\范凯森\\Downloads\\' + sp + '')
        mysheet = wb.sheet_names()
        # tab = wb.sheet_by_name(mysheet[0])
        # data = tab.col_values(0)[1]
        logger.info(mysheet[0])
        try:
            assert mysheet[0] == '产品包导出节目详情'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_Join_blacklist(self):
        """加入黑名单"""
        # VodSearch.test_Sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.dj_chanpguanl()  # 产品管理
        homepage.collapseOne()  # 产品列表
        Select(driver.find_element_by_id('isLine')).select_by_value('1')  # 在线状态下拉框并选择上线
        time.sleep(1)
        initial = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr[1]/td[3]').text  # 获取初始名称     非常静距离 高清
        homepage.table_input()  # 点击复选
        homepage.addBlackBtn()  # 点击加入黑名单
        business = driver.find_element_by_xpath('//*[@id="sgList"]/tbody/tr[1]/td[2]').text  #  获取第一个业务分组名称     KS自动化接口
        homepage.sgList()       #  点击复选
        homepage.btnAddBlackSave()       #  点击确认
        try:
            assert VodSearch.get_ass_text(self) == '添加成功。'
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.confirm_1()    #确认按钮
        homepage.servicegrouping()    #业务分组
        homepage.searchText(business)    #输入名称
        homepage.searchText(Keys.ENTER)    #搜索
        homepage.special_poster()    #点击黑名单
        homepage.prdName(initial)    #输入产品名称
        homepage.prdName(Keys.ENTER)    #搜索
        product = driver.find_element_by_xpath('//*[@id="productTable"]/tbody/tr/td[2]').text
        try:
            assert product == initial
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()
        homepage.productTable()  #  点击复选
        homepage.customtoolbar2()  #  点击删除
        driver.switch_to_alert().accept()
        homepage.confirm_1()        #  确认


    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()





