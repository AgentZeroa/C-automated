# coding=utf-8
import unittest,time,random
from framework.browser_engine import BrowserEngine
from pageobjects.cibn_homepage import HomePage
from selenium.webdriver.support.ui import Select
from Oms_Navigation_management.Global_navigation import Global
from framework.Interface_test import Interface
from framework.logger import Logger

logger = Logger(logger="BrowserEngine").getlog()
Mac = '20:8b:37:39:cb:42'
#升级详情
class Upgrade_detail(unittest.TestCase,Interface):
    @classmethod
    def setUpClass(cls):
        """
        :return:
        """
        browse = BrowserEngine(cls)
        cls.driver = browse.open_browser(cls)

    def test_search(self):
        """搜索"""
        Global.Oms_sign_in(self)
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.busines_com()  # 点击业务组合
        homepage.collapseThrees()  #  点击升级详情
        def allService():
            Select(driver.find_element_by_id('allServiceCombo')).select_by_value(
                '1100121023874101446610014')  # --选择业务组合--   福建联通
            homepage.searchBtn()  #  点击搜索
            homepage.intomac(Mac)  # 输入mac
            homepage.searchByName()  #  点击搜索
        allService()
        Interface.Upgrade_report(self)  # 验证上报接口
        Num = Interface.Upgrade(self)
        driver.refresh()
        allService()
        after_NUM = driver.find_element_by_xpath('//*[@id="table"]/tbody/tr/td[7]').text  #
        try:
            assert after_NUM == str(Num)
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    def test_Reset(self):
        """重置"""
        homepage = HomePage(self.driver)
        driver = self.driver
        homepage.searchReset()  #  点击重置
        mac = driver.find_element_by_xpath('//*[@id="mac"]').text
        apk = driver.find_element_by_xpath('//*[@id="apkVersionSeq"]').text
        try:
            assert mac == '' and apk == ''
            logger.info('Test pass.')
        except Exception as e:
            logger.info("Test fail.", format(e))
            homepage.get_windows_img()

    @classmethod
    def tearDownClass(cls):
        """
        :return:
        """
        cls.driver.quit()
